const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// In-memory game state
const games = {};

function generateBingoCard() {
  const card = [];
  const ranges = [
    [1, 15],   // B
    [16, 30],  // I
    [31, 45],  // N
    [46, 60],  // G
    [61, 75],  // O
  ];
  for (let col = 0; col < 5; col++) {
    const [min, max] = ranges[col];
    const pool = [];
    for (let n = min; n <= max; n++) pool.push(n);
    const picked = pool.sort(() => Math.random() - 0.5).slice(0, 5);
    card.push(picked);
  }
  // card[col][row], center is FREE
  card[2][2] = 'FREE';
  return card;
}

function checkBingo(card, drawn) {
  const drawnSet = new Set(drawn);
  const marked = (col, row) => card[col][row] === 'FREE' || drawnSet.has(card[col][row]);

  // Rows
  for (let row = 0; row < 5; row++) {
    if ([0,1,2,3,4].every(col => marked(col, row))) return true;
  }
  // Columns
  for (let col = 0; col < 5; col++) {
    if ([0,1,2,3,4].every(row => marked(col, row))) return true;
  }
  // Diagonals
  if ([0,1,2,3,4].every(i => marked(i, i))) return true;
  if ([0,1,2,3,4].every(i => marked(i, 4 - i))) return true;

  return false;
}

// Create a new game
app.post('/api/create-game', (req, res) => {
  const gameId = uuidv4().slice(0, 8).toUpperCase();
  const adminKey = uuidv4().slice(0, 12);
  games[gameId] = {
    gameId,
    adminKey,
    players: {},
    drawnNumbers: [],
    allNumbers: Array.from({ length: 75 }, (_, i) => i + 1),
    started: false,
    winner: null,
  };
  res.json({ gameId, adminKey });
});

// Get game state (public)
app.get('/api/game/:gameId', (req, res) => {
  const game = games[req.params.gameId];
  if (!game) return res.status(404).json({ error: 'Game not found' });
  const { adminKey, ...publicGame } = game;
  res.json(publicGame);
});

io.on('connection', (socket) => {

  // Admin connects
  socket.on('admin-join', ({ gameId, adminKey }) => {
    const game = games[gameId];
    if (!game || game.adminKey !== adminKey) {
      socket.emit('error', 'Invalid admin credentials');
      return;
    }
    socket.join(gameId);
    socket.join(`admin-${gameId}`);
    socket.emit('game-state', sanitizeGame(game));
  });

  // Player joins
  socket.on('player-join', ({ gameId, playerName }) => {
    const game = games[gameId];
    if (!game) { socket.emit('error', 'Game not found'); return; }
    if (game.winner) { socket.emit('error', 'This game has already ended'); return; }
    if (Object.keys(game.players).length >= 10 && !game.players[socket.id]) {
      socket.emit('error', 'Game is full (max 10 players)'); return;
    }

    const name = (playerName || 'Player').trim().slice(0, 20);

    // Reuse existing card if same socket reconnects
    if (!game.players[socket.id]) {
      game.players[socket.id] = {
        id: socket.id,
        name,
        card: generateBingoCard(),
        joinedAt: Date.now(),
      };
    }

    socket.join(gameId);
    socket.emit('player-state', {
      player: game.players[socket.id],
      drawnNumbers: game.drawnNumbers,
      winner: game.winner,
    });

    // Notify admin of updated player list
    io.to(`admin-${gameId}`).emit('players-update', getPlayerList(game));
  });

  // Admin draws a number
  socket.on('draw-number', ({ gameId, adminKey }) => {
    const game = games[gameId];
    if (!game || game.adminKey !== adminKey) return;
    if (game.winner) { socket.emit('error', 'Game already has a winner'); return; }

    const remaining = game.allNumbers.filter(n => !game.drawnNumbers.includes(n));
    if (remaining.length === 0) {
      socket.emit('error', 'All numbers have been drawn');
      return;
    }

    const number = remaining[Math.floor(Math.random() * remaining.length)];
    game.drawnNumbers.push(number);

    // Check all cards for bingo
    let winners = [];
    for (const player of Object.values(game.players)) {
      if (checkBingo(player.card, game.drawnNumbers)) {
        winners.push(player.name);
      }
    }

    if (winners.length > 0 && !game.winner) {
      game.winner = winners.join(', ');
    }

    const payload = {
      number,
      drawnNumbers: game.drawnNumbers,
      winner: game.winner,
    };

    io.to(gameId).emit('number-drawn', payload);
  });

  // Admin resets game
  socket.on('reset-game', ({ gameId, adminKey }) => {
    const game = games[gameId];
    if (!game || game.adminKey !== adminKey) return;
    game.drawnNumbers = [];
    game.winner = null;
    // Regenerate all cards
    for (const player of Object.values(game.players)) {
      player.card = generateBingoCard();
    }
    io.to(gameId).emit('game-reset', { drawnNumbers: [], winner: null });
    io.to(gameId).emit('number-drawn', { number: null, drawnNumbers: [], winner: null });
    io.to(`admin-${gameId}`).emit('players-update', getPlayerList(game));
    io.to(`admin-${gameId}`).emit('game-state', sanitizeGame(game));
  });

  socket.on('disconnect', () => {
    // Players are identified by socket.id; on disconnect we keep their card
    // so a refresh doesn't lose their spot (they rejoin with same name)
  });
});

function sanitizeGame(game) {
  const { adminKey, ...pub } = game;
  return { ...pub, players: getPlayerList(game) };
}

function getPlayerList(game) {
  return Object.values(game.players).map(p => ({
    id: p.id,
    name: p.name,
    joinedAt: p.joinedAt,
  }));
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Bingo server running on port ${PORT}`));
