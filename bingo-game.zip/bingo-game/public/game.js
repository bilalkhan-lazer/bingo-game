/* ── Utilities ── */
const $ = id => document.getElementById(id);
const COLS = ['B','I','N','G','O'];
const RANGES = { B:[1,15], I:[16,30], N:[31,45], G:[46,60], O:[61,75] };

function colForNumber(n) {
  if (n >= 1  && n <= 15) return 'B';
  if (n >= 16 && n <= 30) return 'I';
  if (n >= 31 && n <= 45) return 'N';
  if (n >= 46 && n <= 60) return 'G';
  return 'O';
}

function showView(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  $(id).classList.add('active');
}

function setBallColor(el, number) {
  el.classList.remove('b-col','i-col','n-col','g-col','o-col');
  if (!number || number === '—') return;
  el.classList.add(colForNumber(number).toLowerCase() + '-col');
}

function renderDrawnNumbers(prefix, drawn) {
  const counts = { B:[], I:[], N:[], G:[], O:[] };
  drawn.forEach(n => counts[colForNumber(n)].push(n));
  COLS.forEach(col => {
    const el = $(`${prefix}-drawn-${col}`);
    if (!el) return;
    el.innerHTML = counts[col]
      .sort((a,b) => a-b)
      .map(n => `<div class="drawn-num ${col.toLowerCase()}">${n}</div>`)
      .join('');
  });
  const countEl = $(prefix === 'p' ? 'p-drawn-count' : 'drawn-count');
  if (countEl) countEl.textContent = drawn.length;
}

/* ── Routing: read URL params ── */
const params = new URLSearchParams(location.search);
const urlGameId  = params.get('game');
const urlAdminKey = params.get('admin');
const urlName    = params.get('name');

/* ── Socket ── */
const socket = io();

socket.on('error', msg => alert(msg));

/* ══════════════════════════════════════════
   HOME
══════════════════════════════════════════ */
if (!urlGameId) {
  showView('view-home');

  $('btn-create').addEventListener('click', async () => {
    const res = await fetch('/api/create-game', { method: 'POST' });
    const { gameId, adminKey } = await res.json();
    location.href = `/?game=${gameId}&admin=${adminKey}`;
  });

  $('btn-join').addEventListener('click', () => {
    const gameId = $('join-game-id').value.trim().toUpperCase();
    const name   = $('join-name').value.trim();
    if (!gameId) { alert('Enter a game ID'); return; }
    if (!name)   { alert('Enter your name'); return; }
    location.href = `/?game=${gameId}&name=${encodeURIComponent(name)}`;
  });

/* ══════════════════════════════════════════
   ADMIN
══════════════════════════════════════════ */
} else if (urlAdminKey) {
  showView('view-admin');
  $('admin-game-id').textContent = urlGameId;

  const playerLink = `${location.origin}/?game=${urlGameId}`;

  $('btn-copy-player-link').addEventListener('click', () => {
    navigator.clipboard.writeText(playerLink);
    $('btn-copy-player-link').textContent = '✅ Copied!';
    setTimeout(() => $('btn-copy-player-link').textContent = '📋 Copy Player Link', 2000);
  });

  socket.emit('admin-join', { gameId: urlGameId, adminKey: urlAdminKey });

  socket.on('game-state', ({ players, drawnNumbers, winner }) => {
    renderDrawnNumbers('', drawnNumbers);
    renderPlayerList(players);
    if (winner) showWinner(winner);
  });

  socket.on('players-update', players => {
    renderPlayerList(players);
  });

  socket.on('number-drawn', ({ number, drawnNumbers, winner }) => {
    if (number) {
      const ball = $('current-ball');
      ball.textContent = number;
      ball.classList.remove('ball-animate');
      void ball.offsetWidth;
      ball.classList.add('ball-animate');
      setBallColor(ball, number);
      const col = colForNumber(number);
      $('current-label').textContent = `${col} — ${number}`;
    }
    renderDrawnNumbers('', drawnNumbers);
    if (winner) showWinner(winner);
  });

  socket.on('game-reset', () => {
    $('current-ball').textContent = '—';
    $('current-ball').className = 'ball ball-lg';
    $('current-label').textContent = 'Waiting to draw';
    $('winner-overlay').classList.add('hidden');
    renderDrawnNumbers('', []);
  });

  $('btn-draw').addEventListener('click', () => {
    socket.emit('draw-number', { gameId: urlGameId, adminKey: urlAdminKey });
  });

  $('btn-reset').addEventListener('click', () => {
    if (confirm('Reset the game? All cards will be reshuffled.')) {
      socket.emit('reset-game', { gameId: urlGameId, adminKey: urlAdminKey });
    }
  });

  function renderPlayerList(players) {
    $('player-count').textContent = players.length;
    $('player-list').innerHTML = players.length === 0
      ? `<p style="color:var(--muted);font-size:0.85rem;">Waiting for players to join…<br><br>Share this link with your team:<br><code style="word-break:break-all;font-size:0.8rem;color:var(--b)">${playerLink}</code></p>`
      : players.map(p => `
          <div class="player-item">
            <div class="player-avatar">${p.name[0].toUpperCase()}</div>
            <div class="player-info">
              <div class="player-item-name">${escHtml(p.name)}</div>
            </div>
          </div>`).join('');
  }

/* ══════════════════════════════════════════
   PLAYER
══════════════════════════════════════════ */
} else {
  showView('view-player');
  $('player-game-id').textContent = urlGameId;
  $('player-name-display').textContent = urlName || 'Player';

  let myCard = null;

  socket.emit('player-join', { gameId: urlGameId, playerName: urlName });

  socket.on('player-state', ({ player, drawnNumbers, winner }) => {
    myCard = player.card;
    renderCard(myCard, drawnNumbers);
    renderDrawnNumbers('p', drawnNumbers);
    if (winner) showWinner(winner);
  });

  socket.on('number-drawn', ({ number, drawnNumbers, winner }) => {
    if (number && myCard) {
      const ball = $('last-ball');
      ball.textContent = number;
      ball.classList.remove('ball-animate');
      void ball.offsetWidth;
      ball.classList.add('ball-animate');
      setBallColor(ball, number);
      const col = colForNumber(number);
      $('last-label').textContent = `${col} — ${number}`;
      updateCard(myCard, number);
    }
    renderDrawnNumbers('p', drawnNumbers);
    if (winner) showWinner(winner);
  });

  socket.on('game-reset', ({ drawnNumbers }) => {
    // Server will resend player-state; just clear the board
    $('last-ball').textContent = '—';
    $('last-ball').className = 'ball ball-md';
    $('last-label').textContent = 'Waiting for first draw…';
    $('winner-overlay').classList.add('hidden');
    renderDrawnNumbers('p', []);
  });

  socket.on('player-state', ({ player, drawnNumbers, winner }) => {
    myCard = player.card;
    renderCard(myCard, drawnNumbers);
    renderDrawnNumbers('p', drawnNumbers);
    if (winner) showWinner(winner);
  });

  function renderCard(card, drawn) {
    const drawnSet = new Set(drawn);
    const grid = $('bingo-card');
    grid.innerHTML = '';
    for (let row = 0; row < 5; row++) {
      for (let col = 0; col < 5; col++) {
        const val = card[col][row];
        const cell = document.createElement('div');
        cell.className = 'bingo-cell';
        cell.dataset.col = col;
        cell.dataset.row = row;

        if (val === 'FREE') {
          cell.classList.add('free');
          cell.textContent = 'FREE';
        } else {
          cell.textContent = val;
          if (drawnSet.has(val)) cell.classList.add('marked');
        }
        grid.appendChild(cell);
      }
    }
  }

  function updateCard(card, newNumber) {
    for (let row = 0; row < 5; row++) {
      for (let col = 0; col < 5; col++) {
        if (card[col][row] === newNumber) {
          const cells = $('bingo-card').querySelectorAll('.bingo-cell');
          const idx = row * 5 + col;
          const cell = cells[idx];
          if (cell && !cell.classList.contains('marked')) {
            cell.classList.add('marked', 'new-mark');
            cell.addEventListener('animationend', () => cell.classList.remove('new-mark'), { once: true });
          }
        }
      }
    }
  }
}

/* ── Shared: winner overlay ── */
function showWinner(name) {
  $('winner-name').textContent = name;
  $('winner-overlay').classList.remove('hidden');
  $('winner-overlay').addEventListener('click', () => {
    $('winner-overlay').classList.add('hidden');
  }, { once: true });
}

function escHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
